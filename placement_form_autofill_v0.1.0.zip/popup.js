const DEFAULT_KEY = 'profilesV1';

function $(id){return document.getElementById(id)}

function setStatus(msg, isError){
  const s = $('status');
  s.textContent = msg || '';
  s.style.color = isError ? '#c00' : '#666';
}

function validateProfile(p){
  if(!p.fullName || p.fullName.trim().length < 3) return 'Full name is required';
  if(!p.email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(p.email)) return 'A valid email is required';
  return null;
}

// Helper: read profiles map from storage, migrate if necessary
function getProfiles(callback){
  chrome.storage.local.get([DEFAULT_KEY], (res)=>{
    let data = res[DEFAULT_KEY];
    if(!data){ callback({}); return; }
    // migration: if data looks like a single profile (has fullName), convert to map
    if(data && typeof data === 'object' && data.fullName){
      const map = { Default: data };
      chrome.storage.local.set({[DEFAULT_KEY]: map}, ()=>callback(map));
      return;
    }
    // otherwise expect map
    callback(data || {});
  });
}

function saveProfilesMap(map, cb){
  chrome.storage.local.set({[DEFAULT_KEY]: map}, cb||(()=>{}));
}

function buildProfileFromForm(){
  return {
    version: 1,
    fullName: $('fullName').value || '',
    email: $('email').value || '',
    phone: $('phone').value || '',
    rollNo: $('rollNo').value || '',
    cgpa: $('cgpa').value || '',
    tenthPercent: $('tenthPercent').value || '',
    twelfthPercent: $('twelfthPercent').value || '',
    resumeLink: $('resumeLink').value || '',
    college: $('college').value || '',
    branch: $('branch') ? $('branch').value || '' : '',
    gender: $('gender') ? $('gender').value || '' : '',
    relocate: $('relocate') ? $('relocate').value || '' : '',
    lastUpdated: Date.now()
  };
}

function populateProfileSelect(map){
  const sel = $('profileSelect');
  sel.innerHTML = '';
  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = '-- Select profile --';
  sel.appendChild(placeholder);
  Object.keys(map).forEach(name=>{
    const o = document.createElement('option');
    o.value = name; o.textContent = name;
    sel.appendChild(o);
  });
}

function loadProfileIntoForm(profile){
  if(!profile) return;
  $('fullName').value = profile.fullName || '';
  $('email').value = profile.email || '';
  $('phone').value = profile.phone || '';
  $('rollNo').value = profile.rollNo || '';
  $('cgpa').value = profile.cgpa || '';
  $('tenthPercent').value = profile.tenthPercent || '';
  $('twelfthPercent').value = profile.twelfthPercent || '';
  $('resumeLink').value = profile.resumeLink || '';
  $('college').value = profile.college || '';
  if($('branch')) $('branch').value = profile.branch || '';
  if($('gender')) $('gender').value = profile.gender || '';
  if($('relocate')) $('relocate').value = profile.relocate || '';
}

function clearForm(){
  $('fullName').value = '';
  $('email').value = '';
  $('phone').value = '';
  $('rollNo').value = '';
  $('cgpa').value = '';
  $('tenthPercent').value = '';
  $('twelfthPercent').value = '';
  $('resumeLink').value = '';
  $('college').value = '';
  if($('branch')) $('branch').value = '';
  if($('gender')) $('gender').value = '';
  if($('relocate')) $('relocate').value = '';
}

function loadUI(){
  getProfiles((map)=>{
    populateProfileSelect(map);
    const sel = $('profileSelect');
    // if one profile exists, select it
    const keys = Object.keys(map);
    if(keys.length === 1){ sel.value = keys[0]; loadProfileIntoForm(map[keys[0]]); setStatus('Loaded profile: '+keys[0]); }
  });
  // load injection toggle
  chrome.storage.local.get(['injectionEnabled'], (res)=>{
    const v = typeof res.injectionEnabled === 'undefined' ? true : !!res.injectionEnabled;
    if($('injectionToggle')) $('injectionToggle').checked = v;
  });
}

function saveCurrentProfile(){
  const sel = $('profileSelect').value;
  if(!sel){ setStatus('Select a profile or use Save as new', true); return; }
  const profile = buildProfileFromForm();
  const err = validateProfile(profile);
  if(err){ setStatus(err, true); return; }
  getProfiles((map)=>{
    map[sel] = profile;
    saveProfilesMap(map, ()=>{ setStatus('Saved profile: '+sel); populateProfileSelect(map); $('profileSelect').value = sel; });
  });
}

function saveProfileAsNew(){
  const name = $('profileName').value && $('profileName').value.trim();
  if(!name){ setStatus('Enter a profile name to save as', true); return; }
  getProfiles((map)=>{
    if(map[name] && !confirm('Overwrite existing profile "'+name+'"?')) return;
    const profile = buildProfileFromForm();
    const err = validateProfile(profile);
    if(err){ setStatus(err, true); return; }
    map[name] = profile;
    saveProfilesMap(map, ()=>{ setStatus('Saved profile as: '+name); populateProfileSelect(map); $('profileSelect').value = name; });
  });
}

function deleteCurrentProfile(){
  const sel = $('profileSelect').value;
  if(!sel){ setStatus('Select a profile to delete', true); return; }
  if(!confirm('Delete profile "'+sel+'"? This cannot be undone.')) return;
  getProfiles((map)=>{
    delete map[sel];
    saveProfilesMap(map, ()=>{ setStatus('Deleted profile: '+sel); populateProfileSelect(map); clearForm(); $('profileSelect').value = ''; });
  });
}

function exportCurrentOrAll(){
  const sel = $('profileSelect').value;
  getProfiles((map)=>{
    let payload;
    let filename;
    if(sel && map[sel]){ payload = map[sel]; filename = `profile-${sel}.json`; }
    else{ payload = map; filename = 'profiles.json'; }
    const blob = new Blob([JSON.stringify(payload, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
  });
}

function importProfileFile(file){
  const reader = new FileReader();
  reader.onload = (e)=>{
    try{
      const obj = JSON.parse(e.target.result);
      // if object contains multiple profiles (map), merge
      if(obj && typeof obj === 'object' && !obj.fullName){
        getProfiles((map)=>{
          const merged = Object.assign({}, map, obj);
          saveProfilesMap(merged, ()=>{ populateProfileSelect(merged); setStatus('Imported profiles (merged)'); });
        });
        return;
      }
      // otherwise treat as single profile -> ask for name
      const name = prompt('Enter a name for the imported profile:');
      if(!name) { setStatus('Import cancelled', true); return; }
      const err = validateProfile(obj);
      if(err){ setStatus('Import failed: '+err, true); return; }
      obj.lastUpdated = Date.now();
      getProfiles((map)=>{
        map[name] = obj;
        saveProfilesMap(map, ()=>{ populateProfileSelect(map); $('profileSelect').value = name; loadProfileIntoForm(obj); setStatus('Imported profile as: '+name); });
      });
    }catch(err){ setStatus('Invalid JSON file', true); }
  };
  reader.readAsText(file);
}

document.addEventListener('DOMContentLoaded', ()=>{
  loadUI();
  // dynamic save button: acts as Save (overwrite) when a profile is selected, else Save as new
  function updateSaveButton(){
    const sel = $('profileSelect').value;
    const saveBtn = $('saveBtn');
    if(!sel){
      saveBtn.textContent = 'Save as new';
      saveBtn.onclick = saveProfileAsNew;
    }else{
      saveBtn.textContent = 'Save profile';
      saveBtn.onclick = saveCurrentProfile;
    }
  }
  $('profileSelect').addEventListener('change', (e)=>{ updateSaveButton(); const name = e.target.value; if(!name){ clearForm(); setStatus(''); return; } getProfiles((map)=>{ loadProfileIntoForm(map[name]); setStatus('Loaded profile: '+name); }); });
  // reflect changes to profileName input as well
  $('profileName').addEventListener('input', updateSaveButton);
  updateSaveButton();
  // injection toggle handler
  if($('injectionToggle')){
    $('injectionToggle').addEventListener('change', (e)=>{ try{ chrome.storage.local.set({ injectionEnabled: !!e.target.checked }); setStatus('Injection '+(e.target.checked? 'enabled':'disabled')); }catch(err){} });
  }
  // keep old single-click delete/export/import bindings
  $('saveAsBtn').addEventListener('click', saveProfileAsNew);
  $('deleteBtn').addEventListener('click', deleteCurrentProfile);
  $('exportBtn').addEventListener('click', exportCurrentOrAll);
  $('clearBtn').addEventListener('click', ()=>{ clearForm(); setStatus('Form cleared (not saved)'); });
  $('importBtn').addEventListener('click', ()=>$('importFile').click());
  $('importFile').addEventListener('change', (e)=>{
    const f = e.target.files && e.target.files[0];
    if(f) importProfileFile(f);
    e.target.value = '';
  });
  $('profileSelect').addEventListener('change', (e)=>{
    const name = e.target.value;
    if(!name){ clearForm(); setStatus(''); return; }
    getProfiles((map)=>{ loadProfileIntoForm(map[name]); setStatus('Loaded profile: '+name); });
  });
});

