// content.js - injected into Google Forms pages

importMatcherIfNeeded().catch(()=>{});

function ensureButton(){
  if(!isSupportedForm()) return;
  if(document.getElementById('placement-autofill-btn')) return;
  // container to hold button + profile selector
  const container = document.createElement('div');
  container.id = 'placement-autofill-container';
  // minimal inline styles; stronger rules are injected via CSS below
  container.style.position = 'fixed';
  container.style.bottom = '16px';
  container.style.right = '16px';
  container.style.zIndex = 2147483647;
  container.style.display = 'flex';
  container.style.alignItems = 'center';
  container.style.gap = '8px';
  container.style.pointerEvents = 'auto';
  container.style.opacity = '1';

  // inject a stylesheet to make sure our UI stays on top and visible
  try{
    if(!document.getElementById('af-global-styles')){
      const s = document.createElement('style'); s.id = 'af-global-styles';
      s.textContent = `#placement-autofill-container{position:fixed !important; bottom:16px !important; right:16px !important; z-index:2147483647 !important; display:flex !important; align-items:center !important; gap:8px !important;} #placement-autofill-container button, #placement-autofill-container select{font-family:inherit !important; font-size:13px !important;} #af-preview-overlay, #af-profile-chooser, #af-toast{z-index:2147483647 !important;}`;
      (document.head || document.documentElement).appendChild(s);
    }
  }catch(e){ /* ignore style injection errors */ }

  const btn = document.createElement('button');
  btn.id = 'placement-autofill-btn';
  btn.textContent = 'Autofill Placement Details';
  btn.style.background = '#1a73e8';
  btn.style.color = 'white';
  btn.style.border = 'none';
  btn.style.padding = '10px 14px';
  btn.style.borderRadius = '6px';
  btn.style.boxShadow = '0 2px 6px rgba(0,0,0,0.2)';
  btn.style.pointerEvents = 'auto';
  btn.style.opacity = '1';
  btn.addEventListener('click', onAutofillClicked);

  const sel = document.createElement('select');
  sel.id = 'af-profile-select';
  sel.style.padding = '6px';
  sel.style.borderRadius = '6px';
  sel.style.minWidth = '160px';
  sel.title = 'Select profile for autofill';
  // helper to populate the inline profile select
  function populateInlineProfileSelect(map, last){
    try{
      sel.innerHTML = '';
      const empty = document.createElement('option'); empty.value=''; empty.textContent='-- profile --'; sel.appendChild(empty);
      const keys = map && typeof map === 'object' ? Object.keys(map) : [];
      keys.forEach(name=>{ const o = document.createElement('option'); o.value = name; o.textContent = name; sel.appendChild(o); });
      if(last && map && map[last]) sel.value = last;
    }catch(e){ /* ignore */ }
  }

  // initial populate
  try{ chrome.storage.local.get(['profilesV1','lastUsedProfile'], (res)=>{ populateInlineProfileSelect(res && res.profilesV1 ? res.profilesV1 : {}, res && res.lastUsedProfile); }); }catch(e){}

  // disable autofill button if no profiles available
  try{
    chrome.storage.local.get(['profilesV1'], (res)=>{
      const map = res && res.profilesV1 ? res.profilesV1 : {};
      const has = map && typeof map === 'object' && Object.keys(map).length>0;
      if(!has){ btn.disabled = true; btn.textContent = 'Create a profile first'; btn.style.background = '#888'; }
    });
  }catch(e){}

  sel.addEventListener('change', (e)=>{
    const v = e.target.value;
    try{ if(v) chrome.storage.local.set({ lastUsedProfile: v }); }catch(err){}
    // enable button when a profile is chosen
    try{ if(v){ btn.disabled = false; btn.textContent = 'Autofill Placement Details'; btn.style.background = '#1a73e8'; } }catch(e){}
  });

  // small refresh button so users can refresh the inline list after saving in popup
  const refreshBtn = document.createElement('button');
  refreshBtn.id = 'af-profile-refresh';
  refreshBtn.textContent = '\u21bb';
  refreshBtn.title = 'Refresh profiles';
  refreshBtn.style.padding = '6px 8px';
  refreshBtn.style.borderRadius = '6px';
  refreshBtn.style.border = '1px solid #ddd';
  refreshBtn.addEventListener('click', ()=>{
    try{ chrome.storage.local.get(['profilesV1','lastUsedProfile'], (res)=>{ populateInlineProfileSelect(res && res.profilesV1 ? res.profilesV1 : {}, res && res.lastUsedProfile); }); }catch(e){}
  });

  container.appendChild(sel);
  container.appendChild(refreshBtn);
  container.appendChild(btn);
  // append to documentElement in case some pages override body stacking context
  try{ document.documentElement.appendChild(container); }catch(e){ document.body.appendChild(container); }
  // ensure it's visible; if not, try left placement as fallback
  try{
    const rect = container.getBoundingClientRect();
    const cs = window.getComputedStyle(container);
    if(rect.width === 0 || cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0'){
      container.style.right = 'auto';
      container.style.left = '16px';
      // re-measure
      setTimeout(()=>{ try{ adjustAutofillContainer(); }catch(e){} }, 50);
    }
  }catch(e){}
  // ensure we don't overlap the form's submit control
  try{ adjustAutofillContainer(); }catch(e){}
}

// Keep the autofill container clear of page submit controls
function adjustAutofillContainer(){
  const container = document.getElementById('placement-autofill-container');
  if(!container) return;
  // default offset from bottom
  let bottomOffset = 16;
  // try to find common submit controls (sample pages and real forms)
  const submitEl = document.querySelector('#submitBtn, button[type="submit"], input[type="submit"], .freebirdFormviewerViewFormFooter');
  if(submitEl){
    try{
      const rect = submitEl.getBoundingClientRect();
      // if submit element is within viewport and near bottom, lift the container above it
      if(rect && rect.top && rect.top > 0){
        const lift = Math.max(16, (window.innerHeight - rect.top) + 16);
        bottomOffset = lift;
      }
    }catch(e){ /* ignore measurement errors */ }
  }
  container.style.bottom = `${bottomOffset}px`;
}

function onAutofillClicked(){
  chrome.storage.local.get(['profilesV1'], (res)=>{
    const profiles = res['profilesV1'];
    if(!profiles){
      alert('No profile found. Please open the extension popup and save your profile first.');
      // check global toggle
      try{
        chrome.storage.local.get(['injectionEnabled'], (res)=>{
          const enabled = typeof res.injectionEnabled === 'undefined' ? true : !!res.injectionEnabled;
          if(!enabled) return;
          if(!isSupportedForm()) return;
          if(document.getElementById('placement-autofill-btn')) return;
          injectButton();
        });
        return;
      }catch(e){ /* fallback to direct behavior */ }
      if(!isSupportedForm()) return;
      if(document.getElementById('placement-autofill-btn')) return;
      injectButton();
    }
    const names = Object.keys(profiles || {});
    if(names.length === 0){ alert('No profiles saved.'); return; }
    // try to read lastUsedProfile
    chrome.storage.local.get(['lastUsedProfile'], (r)=>{
      const last = r && r.lastUsedProfile;
      if(last && profiles[last]){
        const profile = profiles[last];
        const candidates = computeCandidatesForProfile(profile);
        if(candidates.length === 0){ alert('No fields could be confidently matched.'); return; }
        showPreviewOverlay(candidates, profile, last);
        return;
      }
      if(names.length === 1){
        const profile = profiles[names[0]];
        const candidates = computeCandidatesForProfile(profile);
        if(candidates.length === 0){ alert('No fields could be confidently matched.'); return; }
        showPreviewOverlay(candidates, profile, names[0]);
        return;
      }
      // multiple profiles: show chooser first
      showProfileChooser(profiles);
    });
  });
}

function computeCandidatesForProfile(profile){
  const candidates = [];

  // Process text-like inputs and textareas
  const textInputs = Array.from(document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], input[type="url"], textarea'));
  textInputs.forEach(inp=>{
    const label = findQuestionTextForElement(inp) || '(no label)';
    let matched = null;
    if(window.AutofillMatcher && typeof window.AutofillMatcher.matchQuestionToField === 'function'){
      const res = window.AutofillMatcher.matchQuestionToField(label, profile);
      if(res && res.key && res.value){ matched = {value: res.value, key: res.key, score: res.score}; }
    }
    if(!matched){
      const val = simpleMatch(label, profile);
      if(val) matched = {value: val, key: 'fallback', score: 50};
      // if label didn't reveal field, use input type as a fallback (email/tel)
      if(!matched){
        try{
          const itype = (inp.getAttribute('type') || '').toLowerCase();
          if(itype === 'email' && profile.email){ matched = { value: profile.email, key: 'email', score: 60 }; }
          else if(itype === 'tel' && profile.phone){ matched = { value: profile.phone, key: 'phone', score: 60 }; }
        }catch(e){/* ignore */}
      }
    }
    if(matched && matched.value){
      candidates.push({type:'text', el: inp, label, key: matched.key, value: matched.value, score: matched.score});
    }
  });

  // Process select elements
  const selects = Array.from(document.querySelectorAll('select'));
  selects.forEach(sel=>{
    const label = findQuestionTextForElement(sel) || sel.getAttribute('aria-label') || '(no label)';
    let matchedField = null;
    if(window.AutofillMatcher && typeof window.AutofillMatcher.matchQuestionToField === 'function'){
      const res = window.AutofillMatcher.matchQuestionToField(label, profile);
      if(res && res.key) matchedField = res.key;
    }
    if(!matchedField){
      // fallback: try simpleMatch on label
      const val = simpleMatch(label, profile);
      if(val) matchedField = 'fallback';
    }
    const options = Array.from(sel.options).map(o=>({value:o.value, label:o.text}));
    // pick best option by direct match first (value or label), then token similarity
    let chosen = null;
    if(matchedField && profile[matchedField]){
      const pvRaw = String(profile[matchedField]);
      const pv = pvRaw.toLowerCase().trim();
      // try exact match on option value or label
      chosen = options.find(opt => (String(opt.value||'').toLowerCase() === pv) || (String(opt.label||'').toLowerCase() === pv));
      if(!chosen){
        // fallback to token overlap on label and value
        let bestScore = 0;
        options.forEach(opt=>{
          const label = String(opt.label||'').toLowerCase();
          const value = String(opt.value||'').toLowerCase();
          const s1 = tokenOverlapScore(pv, label);
          const s2 = tokenOverlapScore(pv, value);
          const s = Math.max(s1, s2);
          if(s > bestScore){ bestScore = s; chosen = opt; }
        });
      }
    }
    if(chosen){
      candidates.push({type:'select', el: sel, label, key: matchedField || 'fallback', chosen, options, score: (chosen?50:0)});
    }
  });

  // Process radio groups and checkbox groups by question container
  const processed = new Set();
  const radioInputs = Array.from(document.querySelectorAll('input[type="radio"]'));
  radioInputs.forEach(r=>{
    // try Google Forms roots first, then fall back to our sample .question structure
    const root = r.closest('.freebirdFormviewerComponentsQuestionBaseRoot') || r.closest('.quantumWizTogglePapercheckboxEl') || r.closest('.question') || r.parentElement;
    if(!root) return;
    if(processed.has(root)) return;
    processed.add(root);
    const options = Array.from(root.querySelectorAll('input[type="radio"]')).map(opt=>({el: opt, label: getOptionLabel(opt)}));
    if(options.length === 0) return;
    // look for Google Forms title selectors, else our sample .q-title, else fallback to root text
    const qTitle = root.querySelector('.freebirdFormviewerComponentsQuestionBaseTitle') || root.querySelector('.freebirdFormviewerComponentsQuestionBaseHeader') || root.querySelector('.q-title');
    const label = (qTitle && (qTitle.innerText || qTitle.textContent)) || root.innerText || '(no label)';
    let matchedField = null;
    if(window.AutofillMatcher && typeof window.AutofillMatcher.matchQuestionToField === 'function'){
      const res = window.AutofillMatcher.matchQuestionToField(label, profile);
      if(res && res.key) matchedField = res.key;
    }
    if(!matchedField){ const val = simpleMatch(label, profile); if(val) matchedField = 'fallback'; }
    // choose option best matching profile[matchedField] or explicit profile properties (gender/relocate)
    let chosen = null;
    // if profile contains an explicit gender or relocate value and the question looks like a gender/relocate question, prefer those
    try{
      const qLower = (label || '').toLowerCase();
      const preferValues = [];
      if(profile.gender) preferValues.push(String(profile.gender).toLowerCase());
      if(profile.relocate) preferValues.push(String(profile.relocate).toLowerCase());
      if(preferValues.length>0){
        // direct match first
        for(const pv of preferValues){
          const direct = options.find(o=> (o.label||'').toLowerCase() === pv );
          if(direct){ chosen = direct; break; }
        }
      }
    }catch(e){/* ignore */}
    // fallback to matchedField token overlap
    if(!chosen && matchedField && profile[matchedField]){
      const pv = String(profile[matchedField]).toLowerCase(); let best = 0; options.forEach(opt=>{ const s = tokenOverlapScore(pv, (opt.label||'').toLowerCase()); if(s>best){ best=s; chosen=opt; }});
    }
    if(chosen){ candidates.push({type:'radio', root, label, key: matchedField, chosenLabel: chosen.label, options, score: 50}); }
  });

  // Checkbox groups
  const checkboxInputs = Array.from(document.querySelectorAll('input[type="checkbox"]'));
  processed.clear();
  checkboxInputs.forEach(cb=>{
    const root = cb.closest('.freebirdFormviewerComponentsQuestionBaseRoot') || cb.closest('.quantumWizTogglePapercheckboxEl') || cb.closest('.question') || cb.parentElement;
    if(!root) return; if(processed.has(root)) return; processed.add(root);
    const options = Array.from(root.querySelectorAll('input[type="checkbox"]')).map(opt=>({el: opt, label: getOptionLabel(opt)}));
    if(options.length === 0) return;
    const qTitle = root.querySelector('.freebirdFormviewerComponentsQuestionBaseTitle') || root.querySelector('.freebirdFormviewerComponentsQuestionBaseHeader') || root.querySelector('.q-title');
    const label = (qTitle && (qTitle.innerText || qTitle.textContent)) || root.innerText || '(no label)';
    let matchedField = null;
    if(window.AutofillMatcher && typeof window.AutofillMatcher.matchQuestionToField === 'function'){
      const res = window.AutofillMatcher.matchQuestionToField(label, profile);
      if(res && res.key) matchedField = res.key;
    }
    if(!matchedField){ const val = simpleMatch(label, profile); if(val) matchedField = 'fallback'; }
    // For checkboxes, match any option tokens present in profile[matchedField]
    const chosen = [];
    if(matchedField && profile[matchedField]){
      const pv = String(profile[matchedField]).toLowerCase(); options.forEach(opt=>{ if(tokenOverlapScore(pv, (opt.label||'').toLowerCase())>0) chosen.push(opt); });
    }
    if(chosen.length>0){ candidates.push({type:'checkbox', root, label, key: matchedField, chosenLabels: chosen.map(c=>c.label), options, score: 50}); }
  });

  return candidates;
}

function getOptionLabel(opt){
  if(!opt) return '';
  if(opt.nextElementSibling && opt.nextElementSibling.innerText) return opt.nextElementSibling.innerText.trim();
  if(opt.parentElement && opt.parentElement.innerText) return opt.parentElement.innerText.trim();
  if(opt.labels && opt.labels.length) return Array.from(opt.labels).map(l=>l.innerText).join(' ').trim();
  return opt.getAttribute('value') || '';
}

function tokenOverlapScore(a, b){
  if(!a || !b) return 0;
  const at = a.split(/\W+/).filter(Boolean);
  const bt = b.split(/\W+/).filter(Boolean);
  if(at.length===0 || bt.length===0) return 0;
  const overlap = at.filter(t=>bt.includes(t)).length;
  return overlap;
}

function showProfileChooser(profiles){
  const existing = document.getElementById('af-profile-chooser');
  if(existing) existing.remove();
  const overlay = document.createElement('div');
  overlay.id = 'af-profile-chooser';
  overlay.style.position = 'fixed';
  overlay.style.top = '16px';
  overlay.style.right = '16px';
  overlay.style.zIndex = 2147483647;
  overlay.style.background = 'white';
  overlay.style.border = '1px solid #ddd';
  overlay.style.padding = '12px';
  overlay.style.boxShadow = '0 6px 20px rgba(0,0,0,0.2)';
  const title = document.createElement('div'); title.style.fontWeight = '600'; title.textContent = 'Choose profile to use';
  overlay.appendChild(title);
  const sel = document.createElement('select'); sel.style.marginTop = '8px'; sel.style.width = '100%';
  Object.keys(profiles).forEach(name=>{ const o = document.createElement('option'); o.value = name; o.textContent = name; sel.appendChild(o); });
  overlay.appendChild(sel);
  const actions = document.createElement('div'); actions.style.marginTop = '10px';
  const useBtn = document.createElement('button'); useBtn.textContent = 'Use profile'; useBtn.style.marginRight='8px';
  const cancelBtn = document.createElement('button'); cancelBtn.textContent = 'Cancel';
  actions.appendChild(useBtn); actions.appendChild(cancelBtn);
  overlay.appendChild(actions);
  document.body.appendChild(overlay);
  cancelBtn.addEventListener('click', ()=>overlay.remove());
  useBtn.addEventListener('click', ()=>{
    const name = sel.value;
    const profile = profiles[name];
    const candidates = computeCandidatesForProfile(profile);
    overlay.remove();
    if(candidates.length === 0){ alert('No fields could be confidently matched for profile: '+name); return; }
    // remember last used profile
    try{ chrome.storage.local.set({ lastUsedProfile: name }); }catch(e){}
    showPreviewOverlay(candidates, profile, name);
  });
}


function showPreviewOverlay(candidates, profile){
  // remove existing overlay if any
  const existing = document.getElementById('af-preview-overlay');
  if(existing) existing.remove();
  const overlay = document.createElement('div');
  overlay.id = 'af-preview-overlay';
  overlay.style.position = 'fixed';
  overlay.style.top = '16px';
  overlay.style.right = '16px';
  overlay.style.zIndex = 2147483647;
  overlay.style.maxWidth = '420px';
  overlay.style.background = 'white';
  overlay.style.border = '1px solid #ddd';
  overlay.style.padding = '12px';
  overlay.style.boxShadow = '0 6px 20px rgba(0,0,0,0.2)';
  overlay.style.fontSize = '13px';
  overlay.innerHTML = `<div style="font-weight:600;margin-bottom:8px">Autofill preview</div>`;
  const list = document.createElement('div');
  list.style.maxHeight = '320px';
  list.style.overflow = 'auto';
  // add select-all control
  const selectAllRow = document.createElement('div');
  selectAllRow.style.marginBottom = '8px';
  selectAllRow.innerHTML = `<label style="font-size:13px"><input type="checkbox" id="af-select-all" checked style="margin-right:8px"> Select all</label>`;
  list.appendChild(selectAllRow);
  candidates.forEach((c, i)=>{
    const row = document.createElement('div');
    row.style.display = 'flex';
    row.style.alignItems = 'flex-start';
    row.style.marginBottom = '8px';
  row.innerHTML = `<input type="checkbox" data-idx="${i}" checked style="margin-right:8px;margin-top:6px"/>`;
    const info = document.createElement('div');
    const title = document.createElement('div'); title.style.fontWeight = '600'; title.textContent = c.label;
    const subtitle = document.createElement('div'); subtitle.style.color = '#444';
    const meta = document.createElement('div'); meta.style.fontSize='11px'; meta.style.color='#888'; meta.textContent = `match: ${c.key} score: ${c.score||0}`;
    if(c.type === 'text'){
      subtitle.textContent = String(c.value);
    }else if(c.type === 'select'){
      // render dropdown
      const sel = document.createElement('select');
      sel.style.width='100%';
      c.options.forEach(opt=>{ const o = document.createElement('option'); o.value=opt.value; o.textContent=opt.label; if(c.chosen && opt.label===c.chosen.label) o.selected=true; sel.appendChild(o); });
      subtitle.appendChild(sel);
      sel.setAttribute('data-idx', i);
    }else if(c.type === 'radio'){
      const dd = document.createElement('select'); dd.style.width='100%';
      c.options.forEach(opt=>{ const o = document.createElement('option'); o.value = opt.label; o.textContent = opt.label; if(opt.label === c.chosenLabel) o.selected = true; dd.appendChild(o); });
      subtitle.appendChild(dd); dd.setAttribute('data-idx', i);
    }else if(c.type === 'checkbox'){
      // render multiple checkboxes
      const container = document.createElement('div');
      c.options.forEach(opt=>{
        const cb = document.createElement('label'); cb.style.display='block'; cb.style.fontSize='13px';
        const input = document.createElement('input'); input.type='checkbox'; input.style.marginRight='6px';
        if(c.chosenLabels && c.chosenLabels.includes(opt.label)) input.checked = true;
        input.setAttribute('data-idx', i);
        input.setAttribute('data-opt', opt.label);
        cb.appendChild(input); cb.appendChild(document.createTextNode(opt.label)); container.appendChild(cb);
      });
      subtitle.appendChild(container);
    }
    info.appendChild(title); info.appendChild(subtitle); info.appendChild(meta);
    row.appendChild(info);
    list.appendChild(row);
  });
  overlay.appendChild(list);
  const actions = document.createElement('div');
  actions.style.marginTop = '10px';
  const applyBtn = document.createElement('button');
  applyBtn.textContent = 'Apply selected';
  applyBtn.style.marginRight = '8px';
  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = 'Cancel';
  actions.appendChild(applyBtn);
  actions.appendChild(cancelBtn);
  overlay.appendChild(actions);
  document.body.appendChild(overlay);

  cancelBtn.addEventListener('click', ()=>overlay.remove());
  // select-all behavior
  const selectAllControl = overlay.querySelector('#af-select-all');
  if(selectAllControl){
    selectAllControl.addEventListener('change', (e)=>{
      const checked = e.target.checked;
      Array.from(overlay.querySelectorAll('input[type="checkbox"][data-idx]')).forEach(cb=>cb.checked = checked);
    });
  }
  applyBtn.addEventListener('click', ()=>{
    const checked = Array.from(overlay.querySelectorAll('input[type="checkbox"]')).filter(cb=>cb.checked).map(cb=>Number(cb.getAttribute('data-idx')));
    checked.forEach(idx=>{
      const c = candidates[idx]; if(!c) return;
      if(c.type === 'text'){
        const inp = c.el; inp.focus(); inp.value = c.value; inp.setAttribute('data-autofill-key', c.key); inp.setAttribute('data-autofill-score', String(c.score || 0)); inp.style.outline = '2px solid rgba(46, 204, 113, 0.6)'; inp.dispatchEvent(new Event('input', {bubbles:true})); inp.dispatchEvent(new Event('change', {bubbles:true}));
      }else if(c.type === 'select'){
        const sel = c.el; const selControl = overlay.querySelector(`select[data-idx="${idx}"]`);
        if(selControl){ sel.value = selControl.value; sel.dispatchEvent(new Event('change',{bubbles:true})); sel.style.outline='2px solid rgba(46, 204, 113, 0.6)'; }
      }else if(c.type === 'radio'){
        const selControl = overlay.querySelector(`select[data-idx="${idx}"]`);
        const chosenLabel = selControl ? selControl.value : c.chosenLabel;
        const opt = c.options.find(o=>o.label === chosenLabel);
        if(opt && opt.el){ opt.el.checked = true; opt.el.dispatchEvent(new Event('change',{bubbles:true})); opt.el.style.outline='2px solid rgba(46, 204, 113, 0.6)'; }
      }else if(c.type === 'checkbox'){
        // find all inputs within overlay with same data-idx
        const inputs = Array.from(overlay.querySelectorAll(`input[type="checkbox"][data-idx="${idx}"]`));
        inputs.forEach(iEl=>{
          const optLabel = iEl.getAttribute('data-opt');
          const opt = c.options.find(o=>o.label === optLabel);
          if(opt && opt.el){ opt.el.checked = iEl.checked; opt.el.dispatchEvent(new Event('change',{bubbles:true})); opt.el.style.outline='2px solid rgba(46, 204, 113, 0.6)'; }
        });
      }
    });
    overlay.remove();
    showToast('Selected fields applied. Please review the form before submitting.');
  });
}

// small toast helper
function showToast(msg, timeout=2500){
  try{
    let t = document.getElementById('af-toast');
    if(t) t.remove();
    t = document.createElement('div');
    t.id = 'af-toast';
    t.style.position = 'fixed';
    t.style.bottom = '24px';
    t.style.left = '50%';
    t.style.transform = 'translateX(-50%)';
    t.style.background = 'rgba(0,0,0,0.85)';
    t.style.color = 'white';
    t.style.padding = '8px 12px';
    t.style.borderRadius = '6px';
    t.style.zIndex = 2147483647;
    t.style.fontSize = '13px';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(()=>{ try{ t.remove(); }catch(e){} }, timeout);
  }catch(e){ try{ alert(msg); }catch(e2){} }
}

function escapeHtml(str){
  return String(str).replace(/[&<>\"]/g, (c)=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c]));
}

function findQuestionTextForElement(el){
  // Google Forms uses complex structure; try nearest label or aria-label
  if(el.getAttribute('aria-label')) return el.getAttribute('aria-label');
  // try preceding text
  // sample pages: .question -> .q-title
  const sampleRoot = el.closest('.question') || el.closest('.gform');
  if(sampleRoot){
    const q = el.closest('.question') ? el.closest('.question').querySelector('.q-title') : sampleRoot.querySelector('.q-title');
    if(q) return q.innerText || q.textContent;
  }
  const p = el.closest('.quantumWizTextinputPaperinputEl') || el.closest('.freebirdFormviewerComponentsQuestionBaseRoot');
  if(p){
    const q = p.querySelector('.freebirdFormviewerComponentsQuestionBaseTitle') || p.querySelector('.freebirdFormviewerComponentsQuestionBaseHeader');
    if(q) return q.innerText || q.textContent;
  }
  // fallback: use placeholder
  if(el.placeholder) return el.placeholder;
  return null;
}

function simpleMatch(label, profile){
  const q = label.toLowerCase();
  if(q.includes('name')) return profile.fullName || '';
  if(q.includes('email')) return profile.email || '';
  if(q.includes('phone') || q.includes('mobile') || q.includes('contact')) return profile.phone || '';
  if(q.includes('roll') || q.includes('enrol') || q.includes('registration')) return profile.rollNo || '';
  if(q.includes('cgpa') || q.includes('gpa') || q.includes('grade')) return profile.cgpa || '';
  if(q.includes('10th') || q.includes('tenth') || q.includes('ssc')) return profile.tenthPercent || '';
  if(q.includes('12th') || q.includes('twelfth') || q.includes('hsc')) return profile.twelfthPercent || '';
  if(q.includes('resume') || q.includes('cv')) return profile.resumeLink || '';
  if(q.includes('college') || q.includes('institution')) return profile.college || '';
  return null;
}

let afObserver = null;
function isSupportedForm(){
  // Basic heuristics for Google Forms and local test pages.
  // Keep production checks for docs.google.com/forms but allow local testing on localhost
  // and pages that use the lightweight sample classes (.gform / .question).
  const host = window.location.hostname || '';
  if(host.includes('docs.google.com') && window.location.pathname.includes('/forms')) return true;
  if(host.includes('forms.gle')) return true;
  // Allow local testing servers (localhost / 127.0.0.1)
  if(host === 'localhost' || host === '127.0.0.1') return true;
  // Other quick heuristics (covers some Google Forms DOM variants)
  if(document.querySelector('.freebirdFormviewerComponentsQuestionBaseRoot')) return true;
  // Also allow our sample pages which use .gform / .question classes
  if(document.querySelector('.gform') || document.querySelector('.question')) return true;
  return false;
}

function monitor(){
  if(!isSupportedForm()) return;
  ensureButton();
  if(afObserver) return; // already observing
  afObserver = new MutationObserver((mutations)=>{
    // only ensure button if body exists
    if(document.body) ensureButton();
    try{ adjustAutofillContainer(); }catch(e){}
    // remove stale overlays if URL changed (basic navigation guard)
    const preview = document.getElementById('af-preview-overlay');
    if(preview && !isSupportedForm()) preview.remove();
  });
  try{ afObserver.observe(document.body, {childList:true, subtree:true}); }catch(e){ /* ignore */ }
  // keep adjusted for resizes
  try{ window.addEventListener('resize', ()=>{ try{ adjustAutofillContainer(); }catch(e){} }); }catch(e){}
}

// listen for storage changes so the inline selector stays in sync with popup saves
try{
  if(chrome && chrome.storage && chrome.storage.onChanged && typeof chrome.storage.onChanged.addListener === 'function'){
    chrome.storage.onChanged.addListener((changes, area) => {
      if(area !== 'local') return;
      const sel = document.getElementById('af-profile-select');
      if(!sel) return;
      // if profilesV1 changed, repopulate
      if(changes.profilesV1){
        const newMap = changes.profilesV1.newValue || {};
        const last = (changes.lastUsedProfile && changes.lastUsedProfile.newValue) || null;
        try{ populateInlineProfileSelect(newMap, last); }catch(e){}
      }else if(changes.lastUsedProfile){
        // only lastUsedProfile changed
        try{ chrome.storage.local.get(['profilesV1','lastUsedProfile'], (res)=>{ if(res) populateInlineProfileSelect(res.profilesV1 || {}, res.lastUsedProfile); }); }catch(e){}
      }
    });
  }
}catch(e){ /* ignore on older browsers */ }

function importMatcherIfNeeded(){
  // placeholder to allow future dynamic imports; currently a no-op
  return Promise.resolve();
}

monitor();
